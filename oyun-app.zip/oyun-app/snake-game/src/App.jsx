import React, { useState, useEffect } from "react";
import "./App.css";

const boardSize = 30;
const initialSnake = [{ x: 15, y: 15 }];
const initialDirection = { x: 0, y: -1 };

const generateFoodPosition = () => {
  return {
    x: Math.floor(Math.random() * boardSize),
    y: Math.floor(Math.random() * boardSize),
  };
};

const App = () => {
  const [snake, setSnake] = useState(initialSnake);
  const [direction, setDirection] = useState(initialDirection);
  const [food, setFood] = useState(generateFoodPosition());
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const handleKeyDown = (event) => {
      switch (event.key) {
        case "ArrowUp":
          if (direction.y === 0) setDirection({ x: 0, y: -1 });
          break;
        case "ArrowDown":
          if (direction.y === 0) setDirection({ x: 0, y: 1 });
          break;
        case "ArrowLeft":
          if (direction.x === 0) setDirection({ x: -1, y: 0 });
          break;
        case "ArrowRight":
          if (direction.x === 0) setDirection({ x: 1, y: 0 });
          break;
        default:
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [direction]);

  useEffect(() => {
    if (gameOver) return;

    const moveSnake = () => {
      const newHead = {
        x: (snake[0].x + direction.x + boardSize) % boardSize,
        y: (snake[0].y + direction.y + boardSize) % boardSize,
      };

      if (
        snake.some(
          (segment) => segment.x === newHead.x && segment.y === newHead.y
        )
      ) {
        setGameOver(true);
        return;
      }

      const newSnake = [newHead, ...snake];
      if (newHead.x === food.x && newHead.y === food.y) {
        setFood(generateFoodPosition());
        setScore(score + 1);
      } else {
        newSnake.pop();
      }

      setSnake(newSnake);
    };

    const interval = setInterval(moveSnake, 150);
    return () => clearInterval(interval);
  }, [snake, direction, food, gameOver, score]);

  return (
    <div>
      <h1>Snake Game</h1>
      <p>Score: {score}</p>
      {gameOver ? (
        <h2>Game Over! Press F5 to restart.</h2>
      ) : (
        <div
          className="board"
          style={{
            gridTemplateRows: `repeat(${boardSize}, 1fr)`,
            gridTemplateColumns: `repeat(${boardSize}, 1fr)`,
          }}
        >
          {Array.from({ length: boardSize * boardSize }).map((_, index) => {
            const x = index % boardSize;
            const y = Math.floor(index / boardSize);
            const isSnake = snake.some(
              (segment) => segment.x === x && segment.y === y
            );
            const isFood = food.x === x && food.y === y;
            return (
              <div
                key={index}
                className={`cell ${isSnake ? "snake" : ""} ${
                  isFood ? "food" : ""
                }`}
              ></div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default App;
